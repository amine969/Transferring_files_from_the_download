#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <io.h>
#include <windows.h>

const char *SOURCE_DIR = "C:/Users/hp/Downloads";
const char *DESKTOP_DIR = "C:/Users/hp/Desktop";

void ensure_directory_exists(const char *path)
{

    if (_access(path, 0) != 0)
    {

#ifdef _WIN32
        mkdir(path);
#else
        mkdir(path, 0777);
#endif
    }
}

const char *get_category_by_extension(const char *filename)
{
    char *ext = strrchr(filename, '.');

    if (ext == NULL)
        return "Others";

    if (stricmp(ext + 1, "jpg") == 0 || stricmp(ext + 1, "png") == 0 ||
        stricmp(ext + 1, "jpeg") == 0 || stricmp(ext + 1, "jfif") == 0)
    {
        return "Images";
    }

    else if (stricmp(ext + 1, "pdf") == 0 || stricmp(ext + 1, "txt") == 0 ||
             stricmp(ext + 1, "docx") == 0 || stricmp(ext + 1, "htm") == 0 ||
             stricmp(ext + 1, "html") == 0)
    {
        return "Docs";
    }
    else if (stricmp(ext + 1, "exe") == 0 || stricmp(ext + 1, "msi") == 0)
    {
        return "Programs";
    }

    return "Others";
}

void process_file_transfer(const char *filename)
{
    char old_path[512];
    char new_path[512];
    char target_folder_path[512];

    const char *category = get_category_by_extension(filename);

    sprintf(target_folder_path, "%s/%s", DESKTOP_DIR, category);
    ensure_directory_exists(target_folder_path);

    sprintf(old_path, "%s/%s", SOURCE_DIR, filename);
    sprintf(new_path, "%s/%s/%s", DESKTOP_DIR, category, filename);

    if (rename(old_path, new_path) == 0)
    {
        printf("[SUCCESS] Moved: %s -> %s\n", filename, category);
        printf("\a");
        fflush(stdout);
    }
    else
    {
        perror("[ERROR]");
    }
}

void organize_downloads()
{
    struct dirent *entry;
    DIR *dp = opendir(SOURCE_DIR);

    if (dp == NULL)
    {
        printf("[CRITICAL ERROR] Cannot open source directory: %s\n", SOURCE_DIR);
        return;
    }

    while ((entry = readdir(dp)) != NULL)
    {
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;

        process_file_transfer(entry->d_name);
    }
    closedir(dp);
}

int main(void)
{
    printf("Starting File Organizer Utility...\n");
    printf("Scanning: %s\n\n", SOURCE_DIR);

    organize_downloads();

    printf("\nTask Finished.\n");
    return 0;
}